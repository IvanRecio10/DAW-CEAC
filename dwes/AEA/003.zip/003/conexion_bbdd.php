<?php 

    $servidor = "localhost";
    $usuario = "root";
    $passwd = "";
    $bbdd = "filmoteca";

?>
