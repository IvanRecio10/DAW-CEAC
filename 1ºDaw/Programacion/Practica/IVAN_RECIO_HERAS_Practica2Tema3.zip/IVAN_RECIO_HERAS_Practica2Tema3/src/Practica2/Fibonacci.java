package Practica2;

public class Fibonacci {
	public static int fibo(int num) {
		int a = 1;
		int b= 1;
		int c = 0;
		if (num < 0) {
    		c = -1;
    	}else {
                if (num == 0){
                    c=0;
                }else if(num == 1 || num == 2){
                    c=1;
                }else{
                    for (int i=0; i<num - 2; i++) {
                            c = a + b;
                            a = b;
                            a = c;
                    }
                }
    	}
		return c;
	}
}
