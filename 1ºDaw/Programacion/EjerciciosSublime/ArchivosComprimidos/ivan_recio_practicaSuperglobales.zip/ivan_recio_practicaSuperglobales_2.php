<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ivan Recio Heras</title>
</head>
<body>
	<?php 

		echo "El ganador es: " . $_GET[array_rand($_GET)]; 

	?>
</body>
</html>